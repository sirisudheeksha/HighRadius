const data = [
  // {
  //   id: 'hack',
  //   label: 'hack',
  //   value: 1,
  // },
  // {
  //   id: 'python',
  //   label: 'python',
  //   value: 243,
  // },
  // {
  //   id: 'stylus',
  //   label: 'stylus',
  //   value: 401,
  // },
  // {
  //   id: 'skulla',
  //   label: 'skulla',
  //   value: 103,
  // },
  // {
  //   id: 'make',
  //   label: 'make',
  //   value: 396,
  // },

  {
    id: 'USD',
    label: 'USD',
    value: 44708,
  },
  {
    id: 'INR',
    label: 'INR',
    value: 0,
  },
  {
    id: 'CAD',
    label: 'CAD',
    value: 7,
  },
  {
    id: 'undefined',
    label: 'undefined',
    value: 2,
  },
];
export default data;
