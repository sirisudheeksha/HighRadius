<h2 class="code-line" data-line-start=0 data-line-end=1 ><a id="Project_Milestone_0"></a>Project Milestone</h2>
<p class="has-line-data" data-line-start="2" data-line-end="4">The mandatory features are compulsory tasks and the optional features are for<br>
extra credit points, which will give you an added advantage.</p>
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>Mandatory Features</th>
<th>Optional Features</th>
</tr>
</thead>
<tbody>
<tr>
<td><input type="checkbox" id="checkbox56" checked="true"><label for="checkbox56">1. UI Creation</label></td>
<td><input type="checkbox" id="checkbox57" checked="true"><label for="checkbox57">1. Predict Button activation with Grid Data</label></td>
</tr>
<tr>
<td><input type="checkbox" id="checkbox58" checked="true"><label for="checkbox58">2. Grid Creation</label></td>
<td><input type="checkbox" id="checkbox59" checked="true"><label for="checkbox59">2. Shortcut search button on Grid for Customer Id</label></td>
</tr>
<tr>
<td><input type="checkbox" id="checkbox60" checked="true"><label for="checkbox60">3. Grid Data Loading</label></td>
<td><input type="checkbox" id="checkbox61"><label for="checkbox61">3. Sorting columns</label></td>
</tr>
<tr>
<td><input type="checkbox" id="checkbox62" checked="true"><label for="checkbox62">4. Crud Operation (ADD/EDIT/DEL)</label></td>
<td><input type="checkbox" id="checkbox63" checked="true"><label for="checkbox63" >4. View - Analytics</label></td>
</tr>
<tr>
<td><input type="checkbox" id="checkbox64" checked="true"><label for="checkbox64">5. Pagination</label></td>
<td></td>
</tr>
<tr>
<td><input type="checkbox" id="checkbox65" checked="true"><label for="checkbox65">6. Advanced Search</label></td>
<td></td>
</tr>
</tbody>
</table>
<br/>
