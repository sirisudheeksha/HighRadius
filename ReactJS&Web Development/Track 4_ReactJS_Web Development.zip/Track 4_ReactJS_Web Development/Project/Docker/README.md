**BUILD DOCKER IMAGE**

```sh
    docker build -t ankurpaul19/highradiustraining-servlet -f Dockerfile-servlet.dockerfile .

    docker build -t ankurpaul19/highradiustraining-flask -f Dockerfile-flask.dockerfile .
```
