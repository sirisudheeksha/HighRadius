function oldVersion(num1) {
	return num1 + 50;
}

console.log(oldVersion(100));

const newVersion = (num1) => num1;

console.log(newVersion(60));
