/* var sum = (x) => x++;
var x = sum(12);
x = sum(12);
console.log(x);
 */

/* let x = 200;
if (true) {
	let x = 100;
}
console.log(x, 100);
 */

/* let x = 100;
let y = "100";
console.log(x == y);
 */

// (() => console.log("Highradius"))();

// console.log([1, 2, 3, 0].reduce((f, n) => f + n));

// console.log(Math.random(1, 100));

// console.log(4 ** 3 + "Kuldeep");

/* let x = 100;
let y = "100";
console.log(x === y);
 */
